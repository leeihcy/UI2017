#include "stdafx.h"
#include "opacity_layer_animate.h"
#include "..\layer.h"

bool OpacityLayerAnimate::Action(Layer& layer, byte from, byte to, LayerAnimateParam* pParam)
{
	layer.ClearTypeAnimate(STORYBOARD_ID_OPACITY);

	if (!pParam)
		return false;

	if (pParam == DefaultLayerAnimateParam)
		pParam = &DefautParam;

	if (from == to)
	{
		if (pParam->GetFinishCallback())
		{
			LayerAnimateFinishParam param = { 0 };
			param.endreason = UIA::ANIMATE_END_NORMAL;
			pParam->GetFinishCallback()(param);
		}
		return true;
	}

	OpacityLayerAnimate* p = new OpacityLayerAnimate(layer);


	UIA::IStoryboard* pStoryboard = p->CreateStoryboard();
	pStoryboard->CreateTimeline(0)->SetParam(
		from,
		to,
		pParam->GetDuration())
		->SetEaseType(pParam->GetEaseType());

	p->StartAnimate(*pStoryboard, *pParam);
	return true;
}


void OpacityLayerAnimate::OnTick(UIA::IStoryboard* pStoryboard)
{ 
	m_layer.SetOpacityRender((byte)pStoryboard->
		GetTimeline(0)->GetCurrentIntValue());

	m_layer.InvalidateForLayerAnimate(m_saveParam.IsBlock());
}

void OpacityLayerAnimate::OnEnd()
{

}
