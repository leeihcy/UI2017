#include "stdafx.h"
#include "layer_animate_base.h"
#include "opacity_layer_animate.h"
#include "..\layer.h"
#include "Src\Base\Application\uiapplication.h"

LayerAnimateParam  LayerAnimateBase::DefautParam;

LayerAnimateBase::LayerAnimateBase(Layer& layer) : m_layer(layer)
{
	m_pPrev = nullptr;
	m_pNext = nullptr;

	m_layer.AddAnimate(this);
}

LayerAnimateBase::~LayerAnimateBase()
{
	m_layer.RemoveAnimate(this);
}

void LayerAnimateBase::Release()
{
	DestroyStoryboard();
	delete this;
}

void  LayerAnimateBase::DestroyStoryboard()
{
	UIA::IAnimateManager* pAni = m_layer.
		GetUIApplication()->GetAnimateMgr();

	pAni->RemoveStoryboardByNotityAndId(
		static_cast<UIA::IAnimateEventCallback*>(this),
		Type());
}

UIA::IStoryboard*  LayerAnimateBase::CreateStoryboard()
{
	UIA::IAnimateManager* pAni = m_layer.
		GetUIApplication()->GetAnimateMgr();

	UIA::IStoryboard* pStoryboard = pAni->CreateStoryboard(
		static_cast<UIA::IAnimateEventCallback*>(this),
		Type());

	return pStoryboard;
}

LayerAnimateBase*  LayerAnimateBase::GetNext()
{
	return m_pNext;
}
void  LayerAnimateBase::SetNext(LayerAnimateBase* p)
{
	m_pNext = p;
}
LayerAnimateBase*  LayerAnimateBase::GetPrev()
{
	return m_pPrev;
}
void  LayerAnimateBase::SetPrev(LayerAnimateBase* p)
{
	m_pPrev = p;
}

void  LayerAnimateBase::StartAnimate(UIA::IStoryboard& s, LayerAnimateParam& param)
{
	m_saveParam = param;
	if (param.IsBlock())
		s.BeginBlock();
	else
		s.Begin();
}

UIA::E_ANIMATE_TICK_RESULT  LayerAnimateBase::OnAnimateTick(
	UIA::IStoryboard* p) 
{
	this->OnTick(p);
	return UIA::ANIMATE_TICK_RESULT_CONTINUE;
}
void  LayerAnimateBase::OnAnimateEnd(
	UIA::IStoryboard*, UIA::E_ANIMATE_END_REASON e) 
{
	this->OnEnd();

	Layer* p = &m_layer;

	if (m_saveParam.GetFinishCallback())
	{
		LayerAnimateFinishParam info = { 0 };
		info.endreason = e;
		m_saveParam.GetFinishCallback()(info);

		// �ص����п����������¶�������this���١���˲���ֱ�������ó�Ա����
	}

	// !=normalʱ�������ǵ�ǰ�������ڱ��µĶ���ȡ�������ʱ��ȥ�������٣����µĶ��������󴥷�
	if (e == UIA::ANIMATE_END_NORMAL)
	{
		// TODO: ��ô�ж�layer��ǰ�ѱ����� ��
		p->TryDestroy();
	}
}