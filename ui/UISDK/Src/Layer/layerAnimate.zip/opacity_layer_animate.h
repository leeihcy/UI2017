#pragma once
#include "layer_animate_base.h"

class OpacityLayerAnimate : public LayerAnimateBase
{
public:
	OpacityLayerAnimate(Layer& o) : LayerAnimateBase(o) {};

private:
	virtual LAYER_ANIMATE_TYPE  Type() override 
	{
		return STORYBOARD_ID_OPACITY;
	}

	virtual void OnTick(UIA::IStoryboard*) override;
	virtual void OnEnd() override;

public:
	static bool Action(Layer& layer, byte from, byte to, LayerAnimateParam* pParam);
};