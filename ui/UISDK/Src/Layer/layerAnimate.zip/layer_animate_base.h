#pragma once
#include "Src\Animate\storyboard.h"
#include "Src\Animate\timeline.h"
#include "Inc\Interface\irenderlayer.h"
namespace UI
{
	class Layer;
}

enum LAYER_ANIMATE_TYPE
{
	STORYBOARD_ID_OPACITY = 1,
	STORYBOARD_ID_XROTATE,
	STORYBOARD_ID_YROTATE,
	STORYBOARD_ID_ZROTATE,
	STORYBOARD_ID_TRANSLATE,
	STORYBOARD_ID_SCALE,
};


class LayerAnimateBase : public UIA::IAnimateEventCallback
{
public:
	LayerAnimateBase(Layer&);
	void  Release();

protected:
	virtual ~LayerAnimateBase();
public:
	virtual LAYER_ANIMATE_TYPE  Type() = 0;

	LayerAnimateBase*  GetNext();
	void  SetNext(LayerAnimateBase*);
	LayerAnimateBase*  GetPrev();
	void  SetPrev(LayerAnimateBase*);

	UIA::IStoryboard*  CreateStoryboard();
	void  DestroyStoryboard();

	void  StartAnimate(UIA::IStoryboard& s, LayerAnimateParam& param);

private:
	virtual UIA::E_ANIMATE_TICK_RESULT  OnAnimateTick(UIA::IStoryboard*) override;
	virtual void  OnAnimateEnd(UIA::IStoryboard*, UIA::E_ANIMATE_END_REASON e) override;

	virtual void OnTick(UIA::IStoryboard*) = 0;
	virtual void OnEnd() = 0;


private:
	LayerAnimateBase*  m_pNext;
	LayerAnimateBase*  m_pPrev;
	
protected:
	Layer&  m_layer;
	LayerAnimateParam  m_saveParam;

public:
	static LayerAnimateParam  DefautParam;
};

